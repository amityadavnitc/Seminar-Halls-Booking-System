<?php
require "conn.php";
$name = $_POST["name"];
$surname = $_POST["surname"];
$username = $_POST["username"];
$password = $_POST["password"];
$mysql_qry = "insert into user values('$name','$surname','$username','$password')";
if($conn->query($mysql_qry) === TRUE){
	echo "1";
}
else{
	echo "UserId already exist !";
}
$conn->close();
?>