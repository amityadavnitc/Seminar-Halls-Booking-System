<?php
$db_name="db_m130299ca";
$mysql_username="m130299ca";
$mysql_password="m130299ca";
$server_name="localhost";
$conn=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);
?>
