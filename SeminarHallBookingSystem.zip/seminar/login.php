<?php
require "conn.php";
$username = $_POST["user_name"];
$password = $_POST["password"];
$mysql_qry="select * from user where userId like '$username' and password like '$password'";
$result=mysqli_query($conn,$mysql_qry);
if(mysqli_num_rows($result)> 0)
	echo "1";
else
	echo "Invalid UserId or Password !";
?>