<?php
$con=mysql_connect("localhost","m130299ca","m130299ca");
mysql_select_db("db_m130299ca");
$result1=mysql_query("select * from seminar_info");
mysql_query("delete from seminar_info where userId='$_POST[username]' and hall_name='$_POST[hall]' and date='$_POST[date]' and time_period='$_POST[time]'");
$result2=mysql_query("select * from seminar_info");
if(mysql_num_rows($result1)>mysql_num_rows($result2)) echo "1";
else echo "0";
?>
