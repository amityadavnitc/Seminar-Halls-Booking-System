<?php
$con=mysqli_connect("localhost","m130299ca","m130299ca","db_m130299ca");
$result=mysqli_query($con,"select * from seminar_info where userId='$_GET[user]' order by date desc");
$response=array();
while($row = mysqli_fetch_array($result))
	array_push($response,array("userId"=>$row[0],"hall_name"=>$row[1],"date"=>$row[2],"time"=>$row[3],"sub"=>$row[4]));
echo json_encode(array("server_response"=>$response));
mysqli_close($con);
?>
