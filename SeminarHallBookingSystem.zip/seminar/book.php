<?php
require "conn.php";
$user = $_POST["username"];
$hall = $_POST["hall"];
$date = $_POST["date"];
$time = $_POST["time"];
$sub = $_POST["sub"];
$mysql_qry = "insert into seminar_info values('$user','$hall','$date','$time','$sub')";
if($conn->query($mysql_qry) === TRUE) echo "1";
else echo "0";
$conn->close();
?>