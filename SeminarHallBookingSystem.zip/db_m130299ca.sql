-- phpMyAdmin SQL Dump
-- version 4.0.10.15
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2016 at 02:07 AM
-- Server version: 5.5.48-MariaDB-wsrep
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_m130299ca`
--

-- --------------------------------------------------------

--
-- Table structure for table `seminar_hall`
--

CREATE TABLE IF NOT EXISTS `seminar_hall` (
  `hall_name` varchar(20) NOT NULL,
  `capacity` int(3) NOT NULL,
  `venue` varchar(20) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  PRIMARY KEY (`hall_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seminar_hall`
--

INSERT INTO `seminar_hall` (`hall_name`, `capacity`, `venue`, `purpose`) VALUES
('Aryabhatta', 123, 'Aryabhatta, NITC', 'Training & Placement, presentation & celebration, Councelling etc.'),
('Bhaskara', 123, 'Bhaskara Hall, NITC', 'Training & Placement, presentation & celebration, Councelling etc.'),
('Chanakya', 123, 'Chanakya, NITC', 'Training & Placement, presentation & celebration, Councelling etc.'),
('CSED', 123, 'CSED Seminar Hall', 'Training & Placement, presentation & celebration, Councelling etc.');

-- --------------------------------------------------------

--
-- Table structure for table `seminar_info`
--

CREATE TABLE IF NOT EXISTS `seminar_info` (
  `userId` varchar(20) NOT NULL,
  `hall_name` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time_period` varchar(20) NOT NULL,
  `sub` varchar(100) NOT NULL,
  PRIMARY KEY (`date`,`time_period`,`hall_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seminar_info`
--

INSERT INTO `seminar_info` (`userId`, `hall_name`, `date`, `time_period`, `sub`) VALUES
('M130299CA', 'Aryabhatta Hall', '2016-04-11', '08:00 AM - 09:00 AM', 'abc'),
('M130299CA', 'Bhaskara Hall', '2016-04-11', '10:00 AM - 11:00 AM', 'xyz'),
('m130299ca', 'CSED Seminar Hall', '2016-04-12', '03:00 PM - 04:00 PM', 'gdfhgfdh'),
('m130299ca', 'CSED Seminar Hall', '2016-04-12', '04:00 PM - 05:00 PM', 'gdfhgfdh'),
('M130300CA', 'Aryabhatta Hall', '2016-04-12', '08:00 AM - 09:00 AM', 'xyz'),
('M130299CA', 'Chanakya Hall', '2016-04-12', '08:00 AM - 09:00 AM', 'xyz'),
('M130300CA', 'Chanakya Hall', '2016-04-13', '08:00 AM - 09:00 AM', 'abc'),
('M130299CA', 'Chanakya Hall', '2016-04-13', '09:00 AM - 10:00 AM', 'xyz'),
('M130299CA', 'Aryabhatta Hall', '2016-05-10', '11:00 AM - 12:00 PM', 'Workshop'),
('M130300CA', 'Aryabhatta Hall', '2016-10-10', '04:00 PM - 05:00 PM', 'Workshop'),
('M130300CA', 'CSED Seminar Hall', '2016-10-12', '02:00 PM - 03:00 PM', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `userId` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `surname`, `userId`, `password`) VALUES
('mac', 'cha', '1234567890', '123'),
('Vikas', 'Gupta', 'Abcd', 'Pqrs'),
('Amit', 'Yadav', 'M130299CA', 'amit'),
('Puja', 'Upadhyaye', 'M130300CA', 'puja'),
('Sreekanth', 'Bheemari', 'M130306CA', '1234'),
('Deepak', 'Baraik', 'm130310ca', 'deepak'),
('Parvej', 'Alam', 'M130519CA', 'alam'),
('Chinna', 'Thambi', 'M130522CA', '5678');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
